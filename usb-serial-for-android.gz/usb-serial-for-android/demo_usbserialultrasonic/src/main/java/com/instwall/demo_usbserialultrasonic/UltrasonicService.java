package com.instwall.demo_usbserialultrasonic;

import android.app.Service;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Created by Administrator on 2017/7/20.
 * 超声波串口数据接收Service：1)接收树莓派串口传过来的数据 2)进行判断发送特定广播
 */


public class UltrasonicService extends Service {
    private static final String TAG = "Serial_Ultrasonic";
    private UsbSerialPort mPort;
    private SerialInputOutputManager mSerialIoManager;
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();
    private StringBuffer sb;
    private int lastTAG = 0;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        init();
    }

    /**
     * init
     */
    private void init() {
        refreshDeviceList();
    }

    /**
     * Get the Device(获取设备，目前只有一个)
     */
    private void refreshDeviceList() {
        new AsyncTask<Void, Void, List<UsbSerialPort>>() {
            @Override
            protected List<UsbSerialPort> doInBackground(Void... params) {
                Log.d(TAG, "Refreshing device list ...");
                final List<UsbSerialDriver> drivers =
                        UsbSerialProber.getDefaultProber().findAllDrivers(MyApplication.mUsbManager);
                final List<UsbSerialPort> result = new ArrayList<>();


                for (final UsbSerialDriver driver : drivers) {
                    final List<UsbSerialPort> ports = driver.getPorts();
                    Log.d(TAG, String.format("+ %s: %s port%s",
                            driver, Integer.valueOf(ports.size()), ports.size() == 1 ? "" : "s"));
                    result.addAll(ports);
                }

                return result;
            }

            @Override
            protected void onPostExecute(List<UsbSerialPort> result) {
                Log.d(TAG, result.size() + "");
                if (result.size() > 0) {//目前只有一个
                    UsbSerialPort port = result.get(0);
                    GetDataFromDevice(port);
                }
            }

        }.execute((Void) null);
    }

    /**
     * 建立联系，获取数据
     *
     * @param port 数据位
     */
    private void GetDataFromDevice(UsbSerialPort port) {
        if (port != null) {
            mPort = port;
            //UsbDeviceConnection connection = MyApplication.mUsbManager.openDevice(mPort.getDriver().getDevice());
            if (MainActivity.connection == null) {
                Log.d(TAG, "Open Device Fail");
                return;
            }
            Log.d(TAG, "Open Device Success");
            try {
                mPort.open(MainActivity.connection);
                mPort.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            } catch (IOException e) {
                e.printStackTrace();
                if (mPort != null) {
                    try {
                        mPort.close();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        }
        onDeviceStateChange();

    }

    private void onDeviceStateChange() {
        stopIoManager();
        startIoManager();
    }

    /**
     * 数据回到监听
     */
    private final SerialInputOutputManager.Listener mListener =
            new SerialInputOutputManager.Listener() {

                @Override
                public void onRunError(Exception e) {
                    Log.d(TAG, "Runner stopped.");
                }

                @Override
                public void onNewData(final byte[] data) {
                    Log.d(TAG, "onNewData");
                    updateReceivedData(data);
                }
            };

    private void startIoManager() {
        if (mPort != null) {
            Log.d(TAG, "Starting io manager ..");
            mSerialIoManager = new SerialInputOutputManager(mPort, mListener);
            mExecutor.submit(mSerialIoManager);
        }
    }

    private void stopIoManager() {
        if (mSerialIoManager != null) {
            Log.d(TAG, "Stopping io manager ..");
            mSerialIoManager.stop();
            mSerialIoManager = null;
        }
    }

    /**
     * @param data 串口接受到的数据
     */
    private void updateReceivedData(byte[] data) {
        String tmp = Util.hexStr2Str(Util.bytesToHexString(data));
        Log.d("Distance", tmp);
//        if (tmp.endsWith("m")) {
//            if (sb != null) {
//                sb.append(tmp);
//                SendBroadcast(sb);
//                sb = null;
//            }
//        } else {
//            if (sb == null) {
//                sb = new StringBuffer();
//            }
//            sb.append(tmp);
//        }
    }

    private void SendBroadcast(StringBuffer sb) {
        sb.deleteCharAt(sb.length() - 1);
        float distance = Float.valueOf(sb.toString());
        Log.d(TAG, "Distance:" + distance);
        if (distance > 0 && distance <= 0.5 && lastTAG != 1) {
            lastTAG = 1;
            Intent intent = new Intent();
            intent.setAction("android.intent.action.SHORT_DISTANCE");
            sendBroadcast(intent);
            Log.d(TAG, "Send BroadCast:android.intent.action.SHORT_DISTANCE");
        } else if (distance > 0.5 && distance <= 1 && lastTAG != 2) {
            lastTAG = 2;
            Intent intent = new Intent();
            intent.setAction("android.intent.action.MIDDLE_DISTANCE");
            sendBroadcast(intent);
            Log.d(TAG, "Send BroadCast:android.intent.action.MIDDLE_DISTANCE");
        } else if (distance > 1 && distance <= 1.7 && lastTAG != 3) {
            lastTAG = 3;
            Intent intent = new Intent();
            intent.setAction("android.intent.action.LONG_DISTANCE");
            sendBroadcast(intent);
            Log.d(TAG, "Send BroadCast:android.intent.action.LONG_DISTANCE");
        } else if (distance > 1.7 && lastTAG != 4) {
            lastTAG = 4;
            Intent intent = new Intent();
            intent.setAction("android.intent.action.COMMON_DISTANCE");
            sendBroadcast(intent);
            Log.d(TAG, "Send BroadCast:android.intent.action.COMMON_DISTANCE");
        }
    }


}
