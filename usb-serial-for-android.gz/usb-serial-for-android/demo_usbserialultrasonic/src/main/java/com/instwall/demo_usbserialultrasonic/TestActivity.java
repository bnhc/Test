package com.instwall.demo_usbserialultrasonic;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.util.HashMap;
import java.util.Iterator;

import ashy.earl.magicshell.clientapi.UsbManagerModule;

/**
 * Created by bnhc on 17-8-22.
 */

public class TestActivity extends Activity {

    private static final String ACTION_USB_PERSSION = "com.android.example.USB_PERMISSION";


    private final BroadcastReceiver mUsbRecevier = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERSSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        //Call Method to set up device communication
                        if (device != null) {
                            Log.d("test", device.getDeviceName() + "" + device.getProductName());
                        }
                    } else {

                    }
                }
            }
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initUsb();
    }

    private void initUsb() {
        //RegistBroadcastReceiver
        IntentFilter filter = new IntentFilter(ACTION_USB_PERSSION);
        registerReceiver(mUsbRecevier, filter);
        //List All USB
        UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
        HashMap<String, UsbDevice> deviceList = manager.getDeviceList();
        Iterator<UsbDevice> deviceIterator = deviceList.values().iterator();
        while (deviceIterator.hasNext()) {
            UsbDevice device = deviceIterator.next();
            Log.d("All_Devices", device.getDeviceName() + " " + device.getProductName());
            UsbManagerModule.get().grantDevicePermission(device);
            if (device.getProductName().equals("U")) {
                new Thread() {
                    @Override
                    public void run() {
                        Byte[] bytes;

                    }
                }.start();
            }
        }


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mUsbRecevier);
    }
}
