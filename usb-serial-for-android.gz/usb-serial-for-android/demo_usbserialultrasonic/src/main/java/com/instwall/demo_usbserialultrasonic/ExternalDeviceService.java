package com.instwall.demo_usbserialultrasonic;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.os.AsyncTask;
import android.os.IBinder;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.util.Log;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.SerialInputOutputManager;
import com.instwall.aidltest.IExternalDeviceAidlInterface;
import com.instwall.aidltest.IExternalDeviceCallback;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import ashy.earl.magicshell.clientapi.UsbManagerModule;

/**
 * Created by bnhc on 17-8-22.
 * <p>
 * Get SerialPort Data from HC-SR04
 */

public class ExternalDeviceService extends Service {
    private static final String TAG = "ExternalDevice";

    //external device State
    private static final int DEVICE_WORK_OK = 0;//Device Ok
    private static final int DEVICE_NONE = 1;//No Device
    private static final int DEVICE_WORK_ERROR = 2;//Device Error

    //external device distance
    private static final float DISTANCE_ERROR = -1;//Distance Error

    private UsbManager usbManager;

    //ubs serial from com.hoho.android.usbserial.driver
    private UsbSerialPort mPort;
    private SerialInputOutputManager mSerialInputOutputManager;
    private final ExecutorService mExecutor = Executors.newSingleThreadExecutor();


    private RemoteCallbackList<IExternalDeviceCallback> mCallbacks = new RemoteCallbackList<>();

    //AIDL Interface
    private IExternalDeviceAidlInterface.Stub iBinder = new IExternalDeviceAidlInterface.Stub() {
        @Override
        public void setValue(int n) throws RemoteException {

        }

        @Override
        public void registerCallback(IExternalDeviceCallback callback) throws RemoteException {
            if (callback != null) {
                mCallbacks.register(callback);
            }
        }

        @Override
        public void unregiserCallback(IExternalDeviceCallback callback) throws RemoteException {
            if (callback != null) {
                mCallbacks.unregister(callback);
            }
        }
    };


    //Device Action BroadcastReceiver
    private BroadcastReceiver deviceBroadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (action != null) {
                switch (action) {
                    case UsbManager.ACTION_USB_DEVICE_ATTACHED:
                        getPermissionForDevices();
                        new MyAsyncTask().execute();
                        break;
                    case UsbManager.ACTION_USB_DEVICE_DETACHED:
                        new MyAsyncTask().execute();
                        break;
                }
            }
        }
    };


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return iBinder;
    }


    @Override
    public void onCreate() {
        init();
    }

    private void init() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        intentFilter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);
        registerReceiver(deviceBroadcastReceiver, intentFilter);
        usbManager = (UsbManager) getSystemService(Context.USB_SERVICE);
        getPermissionForDevices();
    }

    /**
     * Get Permission For USBDevices
     */
    private void getPermissionForDevices() {
        if (usbManager != null) {
            for (UsbDevice usbDevice : usbManager.getDeviceList().values()) {
                if (usbManager.hasPermission(usbDevice)) {
                    //Device which has got the permission
                    Log.d(TAG, "[init][hasPermissionDevices:]" + usbDevice.getProductName());
                } else {
                    UsbManagerModule.get().grantDevicePermission(usbDevice);
                }
            }
            new MyAsyncTask().execute();
        } else {
            Log.d(TAG, "[init][ init usbManager Error]");
        }
    }


    class MyAsyncTask extends AsyncTask<Void, Void, List<UsbSerialPort>> {

        @Override
        protected List<UsbSerialPort> doInBackground(Void... voids) {
            List<UsbSerialDriver> drivers = UsbSerialProber.getDefaultProber().findAllDrivers(usbManager);
            List<UsbSerialPort> result = new ArrayList<>();
            if (drivers.size() > 0) {
                for (UsbSerialDriver driver : drivers) {
                    result.addAll(driver.getPorts());
                }
                return result;
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<UsbSerialPort> usbSerialPorts) {
            int n;
            if (usbSerialPorts != null) {//find Device
                //Start Connection
                Log.d(TAG, "[onPostExecute][numbers of support online device:]" + usbSerialPorts.size());
                getConnectionDevice(usbSerialPorts.get(0));
            } else {//None support device
                Log.d(TAG, "[onPostExecute][None device support]");
                n = mCallbacks.beginBroadcast();
                for (int i = 0; i < n; i++) {
                    try {
                        mCallbacks.getBroadcastItem(i).getExternalDeviceState(DEVICE_NONE);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                }
                mCallbacks.finishBroadcast();
            }
        }
    }

    /**
     * Get Connection with Device
     *
     * @param usbSerialPort SerialPorot
     */
    private void getConnectionDevice(UsbSerialPort usbSerialPort) {
        if (usbSerialPort != null) {
            mPort = usbSerialPort;
            UsbDeviceConnection usbConnection = usbManager.openDevice(mPort.getDriver().getDevice());
            if (usbConnection == null) {
                Log.d(TAG, "[getConnectionDevice][Build Connection Error]");
                return;
            }
            Log.d(TAG, "[getConnectionDevice][Build Connection Success]");
            try {
                mPort.open(usbConnection);
                mPort.setParameters(9600, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);
            } catch (IOException e) {
                e.printStackTrace();
                if (mPort != null) {
                    try {
                        mPort.close();
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        }
        //IoManager
        onDeviceStateIoManager();
    }


    /**
     * 单例子线程读取串口数据
     */
    private void onDeviceStateIoManager() {
        stopIoManager();
        startIoManager();
    }

    private void startIoManager() {
        if (mPort != null) {
            mSerialInputOutputManager = new SerialInputOutputManager(mPort, serialListener);
            mExecutor.submit(mSerialInputOutputManager);
        }
    }

    private void stopIoManager() {
        if (mSerialInputOutputManager != null) {
            mSerialInputOutputManager.stop();
            mSerialInputOutputManager = null;
        }
    }

    /**
     * 串口数据回调
     */
    private final SerialInputOutputManager.Listener serialListener = new SerialInputOutputManager.Listener() {
        float distance;
        int n;

        @Override
        public void onNewData(byte[] data) {
            distance = Float.valueOf(Util.hexStr2Str(Util.bytesToHexString(data)).substring(0, 4));
            n = mCallbacks.beginBroadcast();
            for (int i = 0; i < n; i++) {
                try {
                    mCallbacks.getBroadcastItem(i).getExternalDeviceDistance(distance);
                    mCallbacks.getBroadcastItem(i).getExternalDeviceState(DEVICE_WORK_OK);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
            mCallbacks.finishBroadcast();
        }

        @Override
        public void onRunError(Exception e) {
            Log.d(TAG, "[onRunError:]" + e.toString());
            n = mCallbacks.beginBroadcast();
            for (int i = 0; i < n; i++) {
                try {
                    mCallbacks.getBroadcastItem(i).getExternalDeviceDistance(DISTANCE_ERROR);
                    mCallbacks.getBroadcastItem(i).getExternalDeviceState(DEVICE_WORK_ERROR);
                } catch (RemoteException e1) {
                    e1.printStackTrace();
                }
            }
            mCallbacks.finishBroadcast();
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(deviceBroadcastReceiver);
    }
}
