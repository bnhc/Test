package com.instwall.demo_usbserialultrasonic;

import android.app.Application;
import android.hardware.usb.UsbManager;

import ashy.earl.magicshell.clientapi.MagicShellClient;

/**
 * Created by Administrator on 2017/7/21.
 */

public class MyApplication extends Application {
    public static UsbManager mUsbManager;
    public static final String TAG = "USB_Test";

    @Override
    public void onCreate() {
        MagicShellClient.get().installMagicShell(this);
        super.onCreate();
    }
}
